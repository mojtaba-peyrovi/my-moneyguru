<?php $__env->startSection('title'); ?>
  Cars | Create
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="col-md-8 offset-md-2 mt-5">
      <div class="card">
        <div class="card-header bg-info">
          Add a Car
        </div>
        <div class="card-body">
          <form method="post" action="/cars">
            <?php echo e(csrf_field()); ?>

              <fieldset class="form-group">
                <label for="year">Car Year</label>
                <input type="text" class="form-control" id="year" name="year">
              </fieldset>

              <fieldset class="form-group">
                <label for="make">Car Make</label>
                <input type="text" class="form-control" id="make" name="make">
              </fieldset>

              <fieldset class="form-group">
                <label for="model">Car Model</label>
                <input type="text" class="form-control" id="model" name="model">
              </fieldset>
              <button type="submit" class="btn btn-primary">Save</button>
          </form>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>